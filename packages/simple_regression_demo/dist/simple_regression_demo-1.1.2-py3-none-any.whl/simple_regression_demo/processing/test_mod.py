def print_test():
    print('test successful!')